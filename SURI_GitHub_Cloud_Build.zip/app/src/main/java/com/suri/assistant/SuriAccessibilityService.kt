package com.suri.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class SuriAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }

    fun swipeNext(): Boolean {
        val path = Path().apply {
            moveTo(500f, 850f)
            lineTo(500f, 250f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 100, 300))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun tapCenter(): Boolean {
        val path = Path().apply { moveTo(500f, 500f) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 50, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: SuriAccessibilityService? = null
            private set
    }
}
