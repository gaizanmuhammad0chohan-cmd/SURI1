package com.suri.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply {
            text = "SURI"
            textSize = 34f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "السلام علیکم! مائیکروفون دبائیں اور حکم دیں۔"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val mic = Button(this).apply {
            text = "🎙 بول کر حکم دیں"
            setOnClickListener { listen() }
        }
        val access = Button(this).apply {
            text = "فون کنٹرول کی اجازت کھولیں"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(mic)
        layout.addView(access)
        setContentView(layout)
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "SURI کو حکم دیں")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_SPEECH)
        } catch (_: Exception) {
            say("آواز کی سہولت اس فون پر دستیاب نہیں۔")
        }
    }

    @Deprecated("Using activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SPEECH && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "آپ نے کہا: $spoken"
            handleCommand(spoken.lowercase(Locale.ROOT))
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("ٹک ٹاک") || command.contains("tiktok") -> openTikTok()
            command.contains("اگلی ویڈیو") || command.contains("next video") -> {
                if (SuriAccessibilityService.instance?.swipeNext() == true) say("اگلی ویڈیو")
                else say("پہلے فون کنٹرول کی اجازت آن کریں۔")
            }
            command.contains("ویڈیو روک") || command.contains("stop video") ||
                command.contains("pause video") -> {
                if (SuriAccessibilityService.instance?.tapCenter() == true) say("کوشش کر رہی ہوں")
                else say("پہلے فون کنٹرول کی اجازت آن کریں۔")
            }
            command.contains("اجازت") || command.contains("accessibility") -> {
                startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            else -> say("یہ حکم ابھی میرے ابتدائی ورژن میں شامل نہیں۔")
        }
    }

    private fun openTikTok() {
        val launch = packageManager.getLaunchIntentForPackage("com.zhiliaoapp.musically")
        if (launch != null) {
            startActivity(launch)
            say("ٹک ٹاک کھول رہی ہوں۔")
        } else {
            say("ٹک ٹاک انسٹال نہیں ہے۔")
        }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "suri_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("ur", "PK"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }

    companion object { private const val REQUEST_SPEECH = 501 }
}
